package io.ebso.springbootregistrationlogin.service;

import io.ebso.springbootregistrationlogin.model.User;

import io.ebso.springbootregistrationlogin.web.dto.UserRegistrationDto;

public interface UserService {
	User save(UserRegistrationDto registrationDto);
}
