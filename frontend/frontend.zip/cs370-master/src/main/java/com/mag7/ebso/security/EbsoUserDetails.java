package com.mag7.ebso.security;


public class EbsoUserDetails {
}
