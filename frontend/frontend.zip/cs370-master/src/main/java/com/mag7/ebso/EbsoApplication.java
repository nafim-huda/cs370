package com.mag7.ebso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbsoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbsoApplication.class, args);
	}

}
