package com.mag7.ebso.domain;

public class Order {
}
