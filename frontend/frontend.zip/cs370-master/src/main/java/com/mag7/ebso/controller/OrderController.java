package com.mag7.ebso.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {
}
