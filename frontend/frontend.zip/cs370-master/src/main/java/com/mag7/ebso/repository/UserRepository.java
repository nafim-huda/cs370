package com.mag7.ebso.repository;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {
}
