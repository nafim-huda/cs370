package com.mag7.ebso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbsoApplicationTests {

	@Test
	void contextLoads() {
	}

}
